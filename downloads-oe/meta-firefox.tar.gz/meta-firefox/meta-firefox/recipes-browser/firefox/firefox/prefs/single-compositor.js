pref("layers.acceleration.suppress-multiple", true);
pref("layers.acceleration.toplevel-only", true);
