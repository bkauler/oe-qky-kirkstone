pref("media.omx.enabled", true);
pref("media.omx.core-lib-path", "/usr/local/lib/libomxr_core.so");
