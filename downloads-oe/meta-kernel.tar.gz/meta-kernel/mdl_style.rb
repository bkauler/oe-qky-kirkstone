# Copyright (C) 2021, meta-linux-mainline contributors
# SPDX-License-Identifier: CC0-1.0

rule 'MD013', :code_blocks => false
