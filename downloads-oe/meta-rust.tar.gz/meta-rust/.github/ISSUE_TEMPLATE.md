## Version(s) of meta-rust

## Version(s) of poky and/or oe-core

## Expected result

## Actual result

## Steps to reproduce
